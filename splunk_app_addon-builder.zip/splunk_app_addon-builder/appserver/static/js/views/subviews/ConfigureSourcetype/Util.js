const DEFAULT_CONF_SETTINGS = [
    {
        name: "CHARSET",
        value: "UTF-8"
    },
    {
        name: "SHOULD_LINEMERGE",
        value: "0"
    },
    {
        name: "pulldown_type",
        value: "1"
    },
    {
        name: "category",
        value: "Splunk App Add-on Builder"
    }
];

export {
    DEFAULT_CONF_SETTINGS
};
