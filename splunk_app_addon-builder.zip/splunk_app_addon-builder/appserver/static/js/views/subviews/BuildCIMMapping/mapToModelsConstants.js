const STARTING_ROOT = "root";
const APP = "app";
const MODEL = "model";

export { STARTING_ROOT, APP, MODEL };
