Splunk Add-on Builder version 4.1.1
Copyright (C) 2005-2016 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/AddonBuilder/latest

# Binary File Declaration
bin/ta_generator/resources_lib/aob_py3/markupsafe/_speedups.cpython-38-darwin.so
bin/ta_generator/resources_lib/aob_py3/pvectorc.cpython-37m-darwin.so
bin/ta_generator/resources_lib/aob_py3/pvectorc.cpython-38-darwin.so
bin/ta_generator/resources_lib/aob_py3/setuptools/cli-64.exe
bin/ta_generator/resources_lib/aob_py3/setuptools/gui-64.exe
bin/ta_generator/resources_lib/aob_py3/setuptools/cli.exe
bin/ta_generator/resources_lib/aob_py3/setuptools/cli-32.exe
bin/ta_generator/resources_lib/aob_py3/setuptools/gui-32.exe
bin/ta_generator/resources_lib/aob_py3/setuptools/gui.exe
bin/splunk_app_add_on_builder/markupsafe/_speedups.cpython-38-darwin.so
bin/splunk_app_add_on_builder/pvectorc.cpython-37m-darwin.so
bin/splunk_app_add_on_builder/pvectorc.cpython-38-darwin.so
bin/splunk_app_add_on_builder/setuptools/cli-64.exe
bin/splunk_app_add_on_builder/setuptools/gui-64.exe
bin/splunk_app_add_on_builder/setuptools/cli.exe
bin/splunk_app_add_on_builder/setuptools/cli-32.exe
bin/splunk_app_add_on_builder/setuptools/gui-32.exe
bin/splunk_app_add_on_builder/setuptools/gui.exe
